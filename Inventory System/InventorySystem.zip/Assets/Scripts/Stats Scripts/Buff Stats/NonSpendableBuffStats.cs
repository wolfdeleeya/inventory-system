﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Buff", menuName = "Buffs/Nonspendable Buff")]
public class NonSpendableBuffStats : ItemBuffStats
{
    public Attribute Attribute;
}
