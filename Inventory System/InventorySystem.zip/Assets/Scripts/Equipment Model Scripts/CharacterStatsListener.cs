﻿public interface CharacterStatsListener
{
    void StatsChanged();
}

